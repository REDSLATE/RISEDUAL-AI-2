import React, { useState } from 'react';
import { Mail, Lock, User, Eye, EyeOff, Gift } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';

const AuthForm = ({ tab, onSubmit, error, loading, refCode, onOpenLegal }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ email, password, name });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" data-testid="auth-form">
      {tab === 'register' && refCode && (
        <div className="bg-green-600 border border-emerald-700/40 rounded-xl px-3 py-2 flex items-center gap-2" data-testid="referral-banner">
          <Gift className="w-4 h-4 text-lime-400 flex-shrink-0" />
          <p className="text-lime-300 text-xs">You've been referred! Sign up to get a <strong>7-day free Pro trial</strong>.</p>
        </div>
      )}
      {tab === 'register' && (
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input placeholder="Full name" value={name} onChange={e => setName(e.target.value)}
            className="pl-10 bg-slate-800 border-slate-600 text-white rounded-xl" data-testid="auth-name-input" />
        </div>
      )}
      <div className="relative">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
        <Input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} required
          className="pl-10 bg-slate-800 border-slate-600 text-white rounded-xl" data-testid="auth-email-input" />
      </div>
      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
        <Input type={showPw ? 'text' : 'password'} placeholder="Password" value={password}
          onChange={e => setPassword(e.target.value)} required minLength={6}
          className="pl-10 pr-10 bg-slate-800 border-slate-600 text-white rounded-xl" data-testid="auth-password-input" />
        <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
          {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>

      {error && (
        <div className="bg-orange-800 border border-orange-700/50 text-orange-400 text-sm p-3 rounded-lg" data-testid="auth-error">
          {error}
        </div>
      )}

      {tab === 'register' && (
        <label className="flex items-start gap-2 cursor-pointer" data-testid="auth-terms-label">
          <input
            type="checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="mt-0.5 w-4 h-4 rounded border-slate-600 bg-slate-800 text-[#3DE8D9] focus:ring-[#3DE8D9]"
            data-testid="auth-terms-checkbox"
          />
          <span className="text-slate-400 text-[11px] leading-relaxed">
            I agree to the{' '}
            <button type="button" onClick={() => onOpenLegal?.('terms')} className="text-[#3DE8D9] hover:underline">Terms of Service</button>,{' '}
            <button type="button" onClick={() => onOpenLegal?.('privacy')} className="text-[#3DE8D9] hover:underline">Privacy Policy</button>, and{' '}
            <button type="button" onClick={() => onOpenLegal?.('risk')} className="text-[#3DE8D9] hover:underline">Risk Disclosure</button>.
          </span>
        </label>
      )}

      <Button type="submit" disabled={loading || (tab === 'register' && !agreed)}
        className="w-full bg-[#3DE8D9] hover:bg-[#7AEEE0] text-white font-semibold py-5 rounded-xl"
        data-testid="auth-submit-btn">
        {loading ? 'Please wait...' : tab === 'login' ? 'Log In' : 'Create Account'}
      </Button>
    </form>
  );
};

export default AuthForm;
