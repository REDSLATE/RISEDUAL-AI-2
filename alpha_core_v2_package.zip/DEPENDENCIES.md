# Alpha Core v2 — Package & Dependency Map

Generated for handoff. Read-only export; no app files were modified or deployed.
Secrets, `.env`, API keys, SQLite/`.db` databases, and logs are **excluded**.

## What's in this ZIP

```
alpha_core_v2/                      # the Core v2 package (all 10 modules)
  __init__.py
  autonomy.py                       # Alpha-native autonomy layer (the file you asked about)
  broker.py
  config.py
  contracts.py
  discovery.py
  engine.py
  preflight.py
  receipts.py
  sizing.py
routes/
  admin_alpha_v2.py                 # the /api/admin/alpha-v2/* endpoints (incl. /autonomy)
tests/
  test_alpha_core_v2.py
  test_alpha_core_v2_review_fixes.py
  test_alpha_autonomy.py
  test_public_creds_resolution.py
dependencies/                       # external Alpha backend files the package imports
  services/public_equity_live_executor.py
  services/market_data_pool.py
  services/alpha_hardware_kill_switch.py
  routes/auth.py
```

## What autonomy.py ALREADY does (implemented, tested)

`autonomy.py` is a thin decision layer that sits ABOVE Core v2. It has **no
external Alpha imports** — its only import is the in-package `config.Config`.

- Defines two SEPARATE state machines:
  - `Authority` (OBSERVE / SHADOW / TOEHOLD / AUTONOMOUS / HALT) — the only
    thing that can authorize a live cycle. Fail-safe default = OBSERVE.
  - `ProviderRole` (OFFLINE / SHADOW / ADVISOR / PRIMARY) — **metadata only**,
    never grants trading authority.
- `load_state()` reads env: `ALPHA_AUTONOMY_AUTHORITY`, `ALPHA_AUTONOMY_LIVE`,
  `ALPHA_CORE_V2` (via `Config.enabled`), and `ALPHA_PROVIDER_ROLE_*`.
- `AutonomyState.execute_live()` — the single choke point authorizing a live
  autonomous cycle. Requires ALL of: authority in {TOEHOLD, AUTONOMOUS} AND
  `ALPHA_AUTONOMY_LIVE=1` AND Core v2 armed (`ALPHA_CORE_V2=1`).
- `AutonomyController.tick()` — runs ONE Core v2 cycle via an injected
  `EngineFactory`. Honors HALT (no new cycles), and passes `live=execute_live()`
  to `engine.run_cycle()`. It NEVER touches broker/quote/size/idempotency —
  Core v2 stays authoritative. Fully MC-independent.
- Exposed read-only today via `GET /api/admin/alpha-v2/autonomy` (`load_state`).

## What is NOT built yet (still needs building)

- **No standalone worker/loop.** `AutonomyController` exists but nothing in the
  running backend instantiates it on a schedule — it is only reachable through
  the read-only status endpoint. There is no background task calling `.tick()`
  on an interval, and no wiring of a real `EngineFactory` into a worker.
- **No UI controls** for authority/live-arm (env-driven only right now).
- Session-aware 24/5 quote freshness (still strict 15s RTH gate).
- Milestone 2 "Discernment" in `discovery.py` (curated universe selection).

## External dependency chain (why the `dependencies/` files are included)

autonomy.py itself imports NOTHING outside the package. The external files below
are pulled in only when its *engine factory* actually builds a Core v2 engine:

| External file | Imported by | Purpose |
|---|---|---|
| `services/public_equity_live_executor.py` | `broker.py` (`PublicBroker.from_db`), `preflight.py` (`_live_exec_enabled`) | Public.com broker connectivity, creds resolution, live-exec interlock |
| `services/market_data_pool.py` | `discovery.py` (`market_data_pool as mdp`) | Quote/snapshot source for candidate discovery |
| `services/alpha_hardware_kill_switch.py` | `preflight.py` | Hardware kill-switch check in preflight |
| `routes/auth.py` | `routes/admin_alpha_v2.py` (`get_current_user`) | Owner-role gate on all admin endpoints |

Note: these external files have their own further imports (DB, other services)
that are NOT bundled here — this is a focused export, not a runnable checkout.
For a full runnable copy use the "Save to GitHub" feature.
