import os
import logging
import bcrypt
import httpx
import jwt
import secrets
import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel
from bson import ObjectId

from services.datetime_utils import ensure_utc
# Consolidated auth helpers — single source of truth for JWT + user
# resolution lives in ``services.auth_helpers``. We re-export those
# symbols here so every ``from routes.auth import get_current_user``
# call site across the codebase (routes, tests, admin modules)
# keeps working without a broad rename. If you touch auth logic,
# edit ``services/auth_helpers.py`` only.
from services.auth_helpers import (
    JWT_ALGORITHM,
    get_jwt_secret,
    get_current_user,
    get_optional_user,
)

auth_router = APIRouter(prefix="/api/auth", tags=["auth"])

# Will be set by server.py
db = None

def set_db(database):
    global db
    db = database

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))

def create_access_token(user_id: str, email: str) -> str:
    payload = {"sub": user_id, "email": email, "exp": datetime.now(timezone.utc) + timedelta(minutes=15), "type": "access"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: str) -> str:
    payload = {"sub": user_id, "exp": datetime.now(timezone.utc) + timedelta(days=7), "type": "refresh"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def set_auth_cookies(response: Response, access_token: str, refresh_token: str):
    is_secure = os.environ.get("FRONTEND_URL", "").startswith("https")
    # 2026-09-03 (SEC-002): default to SameSite=Lax so a cross-site
    # attacker can't force the browser to attach the cookie to a
    # state-mutating POST. Same-origin XHR (frontend ↔ its own API)
    # is unaffected. Operators who need cross-site cookies (e.g. a
    # separately-hosted admin panel) can override with
    # ``AUTH_COOKIE_SAMESITE=none``. Only applies to NEW logins /
    # refreshes — existing session cookies keep their prior policy
    # until they expire, so no one is force-logged-out by this
    # change. Layer 2 of the CSRF defense (custom-header
    # enforcement) lives in ``services.csrf_middleware``.
    override = (os.environ.get("AUTH_COOKIE_SAMESITE") or "").strip().lower()
    if override in ("none", "lax", "strict"):
        samesite_val = override
    else:
        samesite_val = "lax"
    # ``SameSite=None`` requires ``Secure``; if an operator sets
    # ``AUTH_COOKIE_SAMESITE=none`` on an http (dev) deployment, the
    # browser will silently reject the cookie. Force-flip to lax to
    # save them the debugging cycle.
    if samesite_val == "none" and not is_secure:
        samesite_val = "lax"
    response.set_cookie(key="access_token", value=access_token, httponly=True, secure=is_secure, samesite=samesite_val, max_age=900, path="/")
    response.set_cookie(key="refresh_token", value=refresh_token, httponly=True, secure=is_secure, samesite=samesite_val, max_age=604800, path="/")

def _get_client_ip(request: Request) -> str:
    """Extract the real client IP, respecting reverse proxies.

    The Kubernetes ingress (and any load balancer in front of the
    backend) makes ``request.client.host`` return the proxy pod's IP
    rather than the actual end-user IP. Pre-2026-05-01 the brute-force
    rate-limiter keyed off ``request.client.host`` directly, which
    meant the ingress's small pool of pod IPs (e.g. 10.219.1.109) got
    bucketed across ALL external users. Five typos by anyone locked
    out everyone routed through that pod for 15 minutes — including
    the testing agent and the admin. That's a DoS-by-typo.

    Standard mitigation: respect ``X-Forwarded-For`` (the first IP in
    the comma-separated list is the original client; subsequent
    entries are proxies) and ``X-Real-IP`` as a fallback. Only fall
    back to ``request.client.host`` when neither header is present.
    """
    xff = request.headers.get("x-forwarded-for") or request.headers.get("X-Forwarded-For")
    if xff:
        # First entry is the original client; comma-split, strip, ignore empties.
        first = xff.split(",")[0].strip()
        if first:
            return first
    real_ip = request.headers.get("x-real-ip") or request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()
    return request.client.host if request.client else "unknown"


# Brute force check
async def check_brute_force(identifier: str):
    try:
        record = await db.login_attempts.find_one({"identifier": identifier})
        if record and record.get("attempts", 0) >= 5:
            locked_until = record.get("locked_until")
            if locked_until:
                # Normalize to timezone-aware UTC (MongoDB may return naive datetimes)
                if hasattr(locked_until, 'tzinfo') and locked_until.tzinfo is None:
                    locked_until = locked_until.replace(tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                if locked_until > now:
                    raise HTTPException(status_code=429, detail="Too many failed attempts. Try again in 15 minutes.")
                else:
                    await db.login_attempts.delete_one({"identifier": identifier})
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"check_brute_force error for {identifier}: {e}")
        # Clear potentially corrupt record so user isn't permanently locked
        try:
            await db.login_attempts.delete_one({"identifier": identifier})
        except Exception:
            pass

async def record_failed_attempt(identifier: str):
    record = await db.login_attempts.find_one({"identifier": identifier})
    attempts = (record.get("attempts", 0) if record else 0) + 1
    update = {"$set": {"attempts": attempts, "last_attempt": datetime.now(timezone.utc)}}
    if attempts >= 5:
        update["$set"]["locked_until"] = datetime.now(timezone.utc) + timedelta(minutes=15)
    await db.login_attempts.update_one({"identifier": identifier}, update, upsert=True)

    # On the exact transition into lockout, emit an audit event to
    # `brute_force_events`. This turns the lockout from a silent 15-min
    # wall into addressable signal: you can tell retroactively whether
    # a lockout was real-attacker activity or a noisy test run, and
    # the same collection doubles as an early-warning feed for
    # credential-stuffing campaigns against the production admin.
    #
    # Parsed identifier shape: ``"<client_ip>:<email>"`` — see
    # ``_get_client_ip`` and the login route for how it's built.
    if attempts == 5:
        try:
            ip, _, email = identifier.partition(":")
            await db.brute_force_events.insert_one({
                "_id": str(uuid.uuid4()),
                "event": "lockout_triggered",
                "client_ip": ip or "unknown",
                "triggered_by_user_email": email or "unknown",
                "attempts_at_trigger": attempts,
                "locked_until": update["$set"]["locked_until"].isoformat(),
                "fired_at": datetime.now(timezone.utc).isoformat(),
            })
        except Exception as e:
            # Never fail the core rate-limit path on audit hiccups.
            logging.warning(f"brute_force_events audit insert failed: {e}")

def user_response(user: dict) -> dict:
    return {
        "id": str(user["_id"]),
        "email": user["email"],
        "name": user.get("name", ""),
        "role": user.get("role", "user"),
        "subscription_status": user.get("subscription_status", "free"),
        "is_active": user.get("is_active", True),
        "trial_ends_at": user.get("trial_ends_at"),
        "founding_member": user.get("founding_member", False),
        "beta_access": user.get("beta_access", False),
        "trading_mode": user.get("trading_mode", "paper"),
        "onboarding_completed": bool(user.get("onboarding_completed", False)),
    }

# --- Models ---
class RegisterRequest(BaseModel):
    email: str
    password: str
    name: str = ""
    ref_code: str = ""

class LoginRequest(BaseModel):
    email: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str
    origin_url: Optional[str] = None

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

class RedeemBetaKeyRequest(BaseModel):
    beta_key: str
    email: str
    password: str
    name: str = ""

# --- Routes ---
@auth_router.post("/register")
async def register(req: RegisterRequest, response: Response):
    try:
        email = req.email.strip().lower()
        if len(req.password) < 6:
            raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
        existing = await db.users.find_one({"email": email})
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
        user_doc = {
            "email": email,
            "password_hash": hash_password(req.password),
            "name": req.name.strip() or email.split("@")[0],
            "role": "user",
            "subscription_status": "free",
            "created_at": datetime.now(timezone.utc),
        }
        result = await db.users.insert_one(user_doc)
        user_doc["_id"] = result.inserted_id

        # Grant signup bonus credits
        try:
            from services.credit_service import grant_signup_bonus
            await grant_signup_bonus(str(user_doc["_id"]))
        except Exception as e:
            logging.warning(f"Signup credit grant error: {e}")

        # Process referral code if provided
        if req.ref_code and req.ref_code.strip():
            try:
                from routes.referral import process_referral_signup
                await process_referral_signup(str(user_doc["_id"]), email, req.ref_code.strip())
                updated = await db.users.find_one({"_id": user_doc["_id"]})
                if updated:
                    user_doc["subscription_status"] = updated.get("subscription_status", "free")
            except Exception as e:
                logging.warning(f"Referral processing error: {e}")

        access = create_access_token(str(user_doc["_id"]), email)
        refresh = create_refresh_token(str(user_doc["_id"]))
        set_auth_cookies(response, access, refresh)
        resp = user_response(user_doc)
        resp["access_token"] = access
        resp["refresh_token"] = refresh
        return resp

    except HTTPException:
        raise
    except Exception:
        logging.exception("Register route failed")
        raise HTTPException(status_code=500, detail="Registration failed")


# ── Google / Emergent Auth ──────────────────────────────────────────
#
# REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT
# URLS, THIS BREAKS THE AUTH. Redirect URL is derived on the frontend
# from window.location.origin.

_EMERGENT_SESSION_DATA_URL = (
    "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"
)


class GoogleSessionRequest(BaseModel):
    session_id: str = ""  # optional body fallback; header is preferred


@auth_router.post("/google/session")
async def google_session(request: Request, response: Response,
                          body: Optional[GoogleSessionRequest] = None):
    """Exchange an Emergent Auth session_id for a first-party JWT.

    Flow:
        1. Frontend redirected to https://auth.emergentagent.com and back
           with #session_id=<id>.
        2. Frontend POSTs this endpoint with the session_id (either as
           the ``X-Session-ID`` header, per the playbook, or in the body).
        3. Backend calls Emergent's /session-data to get {id, email,
           name, picture, session_token}, then upserts the user by
           email in our existing ``users`` collection and issues the
           same JWT access/refresh cookies as email/password login.

    We deliberately do NOT run a parallel Emergent session cookie —
    the app's existing 480+ endpoints all rely on the JWT stored in
    the ``access_token`` cookie via ``get_current_user``. Re-using it
    means Google-signed-in users get the same session semantics as
    everyone else with zero downstream churn.
    """
    session_id = (request.headers.get("X-Session-ID")
                  or request.headers.get("x-session-id")
                  or (body.session_id if body else "")).strip()
    if not session_id:
        raise HTTPException(status_code=400, detail="Missing session_id")

    # Verify with Emergent Auth's session-data endpoint.
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                _EMERGENT_SESSION_DATA_URL,
                headers={"X-Session-ID": session_id},
            )
    except Exception as exc:  # noqa: BLE001
        logging.warning(f"[google_session] emergent auth call failed: {exc}")
        raise HTTPException(status_code=502, detail="Auth provider unreachable")
    if r.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid or expired session_id")
    try:
        data = r.json()
    except Exception:  # noqa: BLE001
        raise HTTPException(status_code=502, detail="Malformed auth provider response")

    email = str(data.get("email") or "").strip().lower()
    name = str(data.get("name") or "").strip()
    picture = str(data.get("picture") or "").strip()
    google_sub = str(data.get("id") or "").strip()
    if not email:
        raise HTTPException(status_code=400, detail="Email missing from provider")

    existing = await db.users.find_one({"email": email})
    is_new_user = existing is None
    if existing:
        # Link Google identity + refresh profile fields, but keep the
        # existing role/subscription/password_hash intact.
        updates = {"last_login_at": datetime.now(timezone.utc)}
        if google_sub and not existing.get("google_id"):
            updates["google_id"] = google_sub
        if picture and not existing.get("picture"):
            updates["picture"] = picture
        if not existing.get("name") and name:
            updates["name"] = name
        await db.users.update_one({"_id": existing["_id"]}, {"$set": updates})
        user_doc = {**existing, **updates}
    else:
        user_doc = {
            "email": email,
            "name": name or email.split("@")[0],
            "picture": picture or None,
            "google_id": google_sub or None,
            "role": "user",
            "subscription_status": "free",
            "auth_provider": "google",
            "created_at": datetime.now(timezone.utc),
            "last_login_at": datetime.now(timezone.utc),
        }
        result = await db.users.insert_one(user_doc)
        user_doc["_id"] = result.inserted_id
        # Grant signup bonus for genuinely new accounts.
        try:
            from services.credit_service import grant_signup_bonus
            await grant_signup_bonus(str(user_doc["_id"]))
        except Exception as exc:  # noqa: BLE001
            logging.warning(f"[google_session] signup credit grant failed: {exc}")

    user_id = str(user_doc["_id"])
    access = create_access_token(user_id, email)
    refresh = create_refresh_token(user_id)
    set_auth_cookies(response, access, refresh)
    resp = user_response(user_doc)
    resp["access_token"] = access
    resp["refresh_token"] = refresh
    resp["is_new_user"] = is_new_user
    return resp


async def _validate_beta_key(beta_key: str, email: str) -> dict:
    """Validate a beta key and email for redemption. Returns waitlist entry or raises."""
    waitlist_entry = await db.waitlist.find_one({"beta_key": beta_key, "status": "invited"}, {"_id": 0})
    if not waitlist_entry:
        raise HTTPException(status_code=400, detail="Invalid or already used beta key")

    expires = waitlist_entry.get("beta_key_expires", "")
    if expires:
        # ``beta_key_expires`` may be stored as ISO string or, after a
        # Mongo round-trip, as a tz-naive datetime. ensure_utc() handles
        # both; an unparseable value is treated as "no expiry".
        expires_dt = ensure_utc(expires)
        if expires_dt is not None and expires_dt < datetime.now(timezone.utc):
            raise HTTPException(status_code=400, detail="Beta key has expired. Contact support for a new one.")

    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered. Log in instead.")

    return waitlist_entry


@auth_router.post("/redeem-beta-key")
async def redeem_beta_key(req: RedeemBetaKeyRequest, response: Response):
    """Redeem a beta access key to create an account with Pro trial access."""
    email = req.email.strip().lower()
    beta_key = req.beta_key.strip().upper()

    if len(req.password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")

    waitlist_entry = await _validate_beta_key(beta_key, email)

    trial_days = 30
    cohort = waitlist_entry.get("cohort", "")
    user_doc = {
        "email": email,
        "password_hash": hash_password(req.password),
        "name": req.name.strip() or email.split("@")[0],
        "role": "user",
        "subscription_status": "pro",
        "beta_access": True,
        "beta_key": beta_key,
        "beta_cohort": cohort or None,
        "founding_member": waitlist_entry.get("founding_member", False),
        "trial_ends_at": (datetime.now(timezone.utc) + timedelta(days=trial_days)).isoformat(),
        "created_at": datetime.now(timezone.utc),
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id

    # Grant custom credit bundle if specified on the waitlist entry
    # (set by the First-50 beta signup flow). Falls through silently
    # when the field is absent — a regular waitlist invite just gets
    # the Pro trial without a credit grant.
    credit_grant = int(waitlist_entry.get("beta_credit_grant") or 0)
    credits_granted = 0
    if credit_grant > 0:
        try:
            from services.credit_service import grant_custom_credits
            credits_granted = await grant_custom_credits(
                user_id=str(user_doc["_id"]),
                amount=credit_grant,
                plan_key="pro",
                reason=f"Beta cohort ({cohort or 'invite'}) — {credit_grant:,} credit grant",
            )
            # Mark the user doc with a granted-at marker so the signup
            # flow's idempotency guard treats this user correctly if
            # they ever re-hit the beta CTA after redeeming.
            await db.users.update_one(
                {"_id": user_doc["_id"]},
                {"$set": {"beta_cohort_granted_at": datetime.now(timezone.utc).isoformat()}},
            )
        except Exception as e:
            logging.warning(f"Beta credit grant failed for {email}: {e}")

    await db.waitlist.update_one(
        {"beta_key": beta_key},
        {"$set": {"status": "active", "activated_at": datetime.now(timezone.utc).isoformat(), "activated_email": email}},
    )

    # Flip the beta_signups `entitlements_granted` flag so admin
    # listings accurately report who has redeemed vs. who is still
    # sitting on an un-redeemed key.
    try:
        await db.beta_signups.update_one(
            {"email": email},
            {"$set": {"entitlements_granted": True, "user_id": str(user_doc["_id"])}},
        )
    except Exception as e:
        logging.warning(f"beta_signups mark-granted failed for {email}: {e}")

    access = create_access_token(str(user_doc["_id"]), email)
    refresh = create_refresh_token(str(user_doc["_id"]))
    set_auth_cookies(response, access, refresh)
    resp = user_response(user_doc)
    resp["access_token"] = access
    resp["refresh_token"] = refresh
    resp["beta_activated"] = True
    resp["founding_member"] = waitlist_entry.get("founding_member", False)
    resp["credits_granted"] = credits_granted
    return resp

@auth_router.post("/login")
async def login(req: LoginRequest, request: Request, response: Response):
    try:
        email = req.email.strip().lower()
        ip = _get_client_ip(request)
        identifier = f"{ip}:{email}"
        await check_brute_force(identifier)
        user = await db.users.find_one({"email": email})
        if not user:
            await record_failed_attempt(identifier)
            raise HTTPException(status_code=401, detail="Invalid email or password")
        pw_hash = user.get("password_hash")
        if not pw_hash:
            logging.error(f"Login failed: user {email} has no password_hash field")
            raise HTTPException(status_code=401, detail="Invalid email or password")
        try:
            pw_match = verify_password(req.password, pw_hash)
        except Exception as e:
            logging.error(f"Password verify error for {email}: {e}")
            pw_match = False
        if not pw_match:
            await record_failed_attempt(identifier)
            raise HTTPException(status_code=401, detail="Invalid email or password")
        if not user.get("is_active", True):
            raise HTTPException(status_code=403, detail="Your account has been deactivated. Contact support.")
        await db.login_attempts.delete_one({"identifier": identifier})
        access = create_access_token(str(user["_id"]), email)
        refresh = create_refresh_token(str(user["_id"]))
        set_auth_cookies(response, access, refresh)
        resp = user_response(user)
        resp["access_token"] = access
        resp["refresh_token"] = refresh
        return resp

    except HTTPException:
        raise
    except Exception:
        logging.exception("Login route failed")
        raise HTTPException(status_code=500, detail="Login failed")

@auth_router.post("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"message": "Logged out"}

@auth_router.get("/me")
async def me(request: Request):
    try:
        user = await get_current_user(request)
        return user_response({"_id": user["_id"], **user})
    except HTTPException:
        raise
    except Exception:
        logging.exception("Me route failed")
        raise HTTPException(status_code=500, detail="Failed to get user info")


async def _extract_refresh_token(request: Request) -> str:
    """Extract refresh token from cookie, body, or Authorization header."""
    token = request.cookies.get("refresh_token")
    if token:
        return token
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    token = body.get("refresh_token") or ""
    if token:
        return token
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return ""


@auth_router.post("/refresh")
async def refresh_token(request: Request, response: Response):
    try:
        token = await _extract_refresh_token(request)
        if not token:
            raise HTTPException(status_code=401, detail="No refresh token")
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        access = create_access_token(str(user["_id"]), user["email"])
        # 2026-09-03 (SEC-002): use shared cookie helper so
        # SameSite/Secure policy stays in one place (the helper
        # respects ``AUTH_COOKIE_SAMESITE`` and defaults to Lax).
        is_secure = os.environ.get("FRONTEND_URL", "").startswith("https")
        override = (os.environ.get("AUTH_COOKIE_SAMESITE") or "").strip().lower()
        samesite_val = override if override in ("none", "lax", "strict") else "lax"
        if samesite_val == "none" and not is_secure:
            samesite_val = "lax"
        response.set_cookie(key="access_token", value=access, httponly=True, secure=is_secure, samesite=samesite_val, max_age=900, path="/")
        return {"access_token": access}
    except HTTPException:
        raise
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Refresh token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    except Exception:
        logging.exception("Refresh route failed")
        raise HTTPException(status_code=500, detail="Token refresh failed")

@auth_router.post("/forgot-password")
async def forgot_password(req: ForgotPasswordRequest):
    try:
        email = req.email.strip().lower()
        user = await db.users.find_one({"email": email})
        if not user:
            return {"message": "If that email exists, a reset link has been sent."}
        token = secrets.token_urlsafe(32)
        await db.password_reset_tokens.insert_one({
            "token": token,
            "user_id": user["_id"],
            "expires_at": datetime.now(timezone.utc) + timedelta(hours=1),
            "used": False,
        })
        try:
            from services.email_service import send_password_reset_email
            await send_password_reset_email(email, token, origin_url=req.origin_url)
        except Exception as e:
            logging.error(f"Failed to send password reset email: {e}")
        return {"message": "If that email exists, a reset link has been sent."}

    except HTTPException:
        raise
    except Exception:
        logging.exception("Forgot password route failed")
        raise HTTPException(status_code=500, detail="Password reset request failed")

@auth_router.post("/reset-password")
async def reset_password(req: ResetPasswordRequest):
    try:
        record = await db.password_reset_tokens.find_one({"token": req.token, "used": False})
        if not record:
            raise HTTPException(status_code=400, detail="Invalid or expired reset token")
        expires_at = record["expires_at"].replace(tzinfo=timezone.utc) if record["expires_at"].tzinfo is None else record["expires_at"]
        if expires_at < datetime.now(timezone.utc):
            raise HTTPException(status_code=400, detail="Invalid or expired reset token")
        if len(req.new_password) < 6:
            raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
        await db.users.update_one({"_id": record["user_id"]}, {"$set": {"password_hash": hash_password(req.new_password)}})
        await db.password_reset_tokens.update_one({"_id": record["_id"]}, {"$set": {"used": True}})
        return {"message": "Password reset successful"}

    except HTTPException:
        raise
    except Exception:
        logging.exception("Reset password route failed")
        raise HTTPException(status_code=500, detail="Password reset failed")

# --- Admin Seeding ---
# Hard-deny list: emails that must NEVER be seeded as owner regardless of env.
# The Red Slate Holdings account was the historical owner — user directive in
# Feb 2026 permanently removed it. If a stale env var still points here,
# override it.
_BANNED_OWNER_EMAILS = {"managingdirector@redslateholdings.com"}
_CANONICAL_OWNER_EMAIL = "admin@risedual.ai"


def _resolve_owner_email() -> str:
    """Return the owner email, forcing the canonical one if env is stale."""
    env_val = os.environ.get("OWNER_EMAIL", _CANONICAL_OWNER_EMAIL).strip().lower()
    if env_val in _BANNED_OWNER_EMAILS or not env_val:
        logging.warning(
            f"OWNER_EMAIL env var points at banned/empty value ({env_val!r}); "
            f"overriding to canonical {_CANONICAL_OWNER_EMAIL}."
        )
        return _CANONICAL_OWNER_EMAIL
    return env_val


OWNER_EMAIL = _resolve_owner_email()
# Owner password: read strictly from the OWNER_PASSWORD environment
# variable (set in `/app/backend/.env` or the Emergent secrets panel).
# Historical context: there used to be a hardcoded `_CANONICAL_OWNER_PASSWORD`
# here as a lockout-prevention measure during the Red Slate Holdings
# migration. The owner confirmed (Feb 2026) that the password is now
# rotated via UI + env, so the hardcoded fallback has been removed per
# security review. `seed_admin()` still gracefully no-ops when the env
# var is unset so an empty secret doesn't rewrite the hash.
OWNER_PASSWORD = os.environ.get("OWNER_PASSWORD", "")

async def seed_admin():
    """Seed the single RISEDUAL owner account.

    Historical note: there used to be two separate seed blocks — `admin` and
    `owner` (Red Slate Holdings). The Red Slate account was deactivated by
    user directive in Feb 2026, and we consolidated to a single owner at
    `admin@risedual.ai`. The one-shot cleanup that used to delete any
    lingering banned-owner rows on startup has been removed (2026-02):
    the cleanup ran successfully on production long ago, so the loop was
    a permanent no-op that violated the deployment safety policy
    ("no destructive DB write on startup"). ``_BANNED_OWNER_EMAILS`` is
    retained and used at import time to reject a misconfigured
    ``OWNER_EMAIL`` env var (see :func:`_resolve_owner_email`) — that
    guard is read-only and stays.
    """
    # Seed RISEDUAL owner
    if not OWNER_PASSWORD:
        logging.warning("OWNER_PASSWORD not set in .env, skipping owner seed")
        return
    existing_owner = await db.users.find_one({"email": OWNER_EMAIL})
    if not existing_owner:
        await db.users.insert_one({
            "email": OWNER_EMAIL,
            "password_hash": hash_password(OWNER_PASSWORD),
            "name": "RISEDUAL",
            "role": "owner",
            "subscription_status": "pro",
            "is_active": True,
            "created_at": datetime.now(timezone.utc),
        })
    else:
        # Always promote to owner — this is the canonical single-admin account.
        updates = {
            "role": "owner",
            "subscription_status": "pro",
            "name": "RISEDUAL",
            "is_active": True,
        }
        existing_hash = existing_owner.get("password_hash")
        needs_rehash = True
        if existing_hash:
            try:
                needs_rehash = not verify_password(OWNER_PASSWORD, existing_hash)
            except Exception as e:
                logging.warning(f"Owner password verify failed during seed: {e}")
        if needs_rehash:
            updates["password_hash"] = hash_password(OWNER_PASSWORD)
        await db.users.update_one({"email": OWNER_EMAIL}, {"$set": updates})

    # Ensure owner has a credit wallet (Pro Max allocation)
    user = await db.users.find_one({"email": OWNER_EMAIL}, {"_id": 1})
    if user:
        uid = str(user["_id"])
        existing_credits = await db.user_credits.find_one({"user_id": uid})
        if not existing_credits:
            await db.user_credits.insert_one({
                "user_id": uid,
                "credits": 50000,
                "total_earned": 50000,
                "total_spent": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })

async def create_indexes():
    await db.users.create_index("email", unique=True)
    await db.password_reset_tokens.create_index("expires_at", expireAfterSeconds=0)
    await db.login_attempts.create_index("identifier")
    await db.waitlist.create_index("email", unique=True, name="unique_email")
    await db.waitlist.create_index("referral_code", unique=True, name="unique_referral_code")
    await db.headlines.create_index("content_hash", unique=True)
    await db.headlines.create_index("expires_at", expireAfterSeconds=0)
    await db.headlines.create_index([("scraped_at", -1)])

    # ── Data-integrity observability (2026-05-01 cleanup) ─────────────
    # These collections grow on every unknown-direction event and
    # nightly invariant run. Without a TTL they'd accumulate forever;
    # 90d is plenty of history for "are we regressing?" trend
    # analysis while keeping the hot path cheap. The dashboard
    # aggregates `fired_at` (ISO string) directly; `fired_at_dt`
    # (BSON Date) exists purely so MongoDB can honour the TTL.
    await db.data_integrity_metrics.create_index(
        "fired_at_dt", expireAfterSeconds=7776000,  # 90 days
        name="ttl_fired_at_dt",
    )
    await db.data_integrity_metrics.create_index([("fired_at", -1)])
    await db.data_integrity_metrics.create_index(
        [("metric", 1), ("fired_at", -1)],
        name="metric_fired_at_desc",
    )
    await db.data_integrity_audits.create_index([("run_id", -1)])
    await db.brute_force_events.create_index([("fired_at", -1)])

    # ── Trades & watchlist symbol lookup (2026-07-07) ──────────────
    # Frontend surfaces sort broker orders/positions by symbol and
    # the watchlist reads by user_id + iterates tickers. These
    # indexes make the paginated symbol scans O(log n) instead of a
    # full collection scan as the trade log grows past ~10k rows.
    await db.trade_orders.create_index([("symbol", 1)], name="symbol_asc")
    await db.trade_orders.create_index(
        [("user_id", 1), ("symbol", 1)], name="user_symbol",
    )
    await db.paper_trades.create_index([("symbol", 1)], name="symbol_asc")
    await db.paper_trades.create_index([("ticker", 1)], name="ticker_asc")
    await db.watchlists.create_index("user_id", name="user_id_idx")

# --- Owner-only guard ---
async def require_owner(request: Request):
    user = await get_current_user(request)
    if user.get("role") != "owner":
        raise HTTPException(status_code=403, detail="Owner access required")
    return user

async def require_admin(request: Request):
    """Require owner OR admin role. 'owner' is the super-admin (the founder)."""
    user = await get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if user.get("role") not in ("owner", "admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# --- Admin Routes (Owner + Admin) ---
@auth_router.get("/admin/users")
async def list_users(request: Request):
    await require_admin(request)
    cursor = db.users.find({}, {"password_hash": 0}).limit(200)
    users = []
    async for u in cursor:
        u["_id"] = str(u["_id"])
        users.append(u)
    return {"users": users, "total": len(users)}

@auth_router.post("/admin/users/{user_id}/activate")
async def activate_user(user_id: str, request: Request):
    await require_admin(request)
    result = await db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"is_active": True}})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User activated"}

@auth_router.post("/admin/users/{user_id}/deactivate")
async def deactivate_user(user_id: str, request: Request):
    await require_admin(request)
    target = await db.users.find_one({"_id": ObjectId(user_id)})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "owner":
        raise HTTPException(status_code=403, detail="Cannot deactivate owner account")
    await db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"is_active": False}})
    return {"message": "User deactivated"}

@auth_router.post("/admin/users/{user_id}/grant-pro")
async def grant_pro(user_id: str, request: Request):
    await require_admin(request)
    result = await db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"subscription_status": "pro"}})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "Pro access granted"}

@auth_router.post("/admin/users/{user_id}/revoke-pro")
async def revoke_pro(user_id: str, request: Request):
    await require_admin(request)
    target = await db.users.find_one({"_id": ObjectId(user_id)})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "owner":
        raise HTTPException(status_code=403, detail="Cannot revoke owner's Pro access")
    await db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"subscription_status": "free"}})
    return {"message": "Pro access revoked"}
