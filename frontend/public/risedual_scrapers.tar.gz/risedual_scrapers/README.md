# RISEDUAL Scrapers — Portable Package

Drop into another brain (Camaro / Chevelle / REDEYE) at `backend/services/`.
Same module path Alpha uses, so imports work unchanged.

---

## What's in the box (16 files, ~5,400 lines)

### Free, no API key needed

| File | Source | What it returns | Notes |
|---|---|---|---|
| `kraken_crypto_quotes.py` | Kraken public REST | bid/ask/spread_bps + 24h base volume for 11 crypto majors | ~1 req/sec rate limit, batched. The **canonical crypto quote source** for the intent snapshot enrichment. |
| `market_sentiment_service.py` | Alternative.me F&G + yfinance VIX | Fear & Greed index 0-100 + historical, VIX-derived regime | Cached. Both APIs are free. |
| `crypto_scraping_service.py` | Binance + Coinbase public APIs | Order book snapshots, large trade prints | Public endpoints, no key needed but rate-limited. |
| `world_events_service.py` | Geopolitical / macro event feeds | Recent world events for council context | Tiny module, mostly orchestration. |
| `real_estate_scraping_service.py` | Public US housing data (Zillow / Redfin proxies) | Median home prices, days on market, regional trends | Web scraping; brittle, may break on layout changes. |
| `sec_13f_service.py` | SEC EDGAR submissions endpoint | Per-filing 13F-HR holdings, QoQ diffs for tracked institutions | Free, 10 req/sec, requires identifying `User-Agent`. Tracks Berkshire, Bridgewater, etc. |

### Paid / API key required

| File | Source | What it returns | Required env |
|---|---|---|---|
| `alpaca_equity_quotes.py` | Alpaca v2 market data | bid/ask/spread_bps for US equities + 1m/1h/1d bars | `ALPACA_API_KEY`, `ALPACA_API_SECRET` |
| `financial_scraping_service.py` | Mixed (yfinance + AV + headers spoof) | Earnings calendar, IPO calendar, analyst estimates | Some endpoints free, some need AV key |
| `company_research_service.py` | Alpha Vantage OVERVIEW with yfinance fallback | P/E, revenue, gross margin, sector, fundamentals | `ALPHA_VANTAGE_API_KEYS` (rotates across keys) |
| `benzinga_news_service.py` | Benzinga news feed (free tier) | Article counts per ticker, headlines | `BENZINGA_API_KEY`; **strict daily ceiling** built in |
| `av_sentiment_feeder.py` | Alpha Vantage NEWS_SENTIMENT | overall_sentiment_score per ticker in [-1, 1] | `ALPHA_VANTAGE_API_KEYS`; paid endpoint |
| `news_shock_service.py` | Reads from `catalyst_events` collection | Z-score classifier — turns news counts + sentiment into NEWS_SHOCK signals | No env; consumes feeders' output |
| `news_shock_feeder.py` | Bridge: Benzinga → `equity_telemetry` | Records per-ticker news counts so NEWS_SHOCK has a baseline | Inherits Benzinga key |
| `polygon_dark_pool_service.py` | Polygon.io grouped daily bars | Estimated dark-pool % (38-47% of US equity volume), whale alerts | `POLYGON_API_KEY` (free tier OK) |
| `fred_service.py` | FRED (Federal Reserve) | Macro indicators: CPI, unemployment, fed funds, etc. | `FRED_API_KEYS` (free, get from St. Louis Fed) |
| `intent_enrichment.py` | Wraps Kraken + Alpaca quotes | The canonical 7-field snapshot every brain must attach to intents | No env; reads other modules |

---

## Drop-in instructions for the receiving brain

1. **Copy files** to `backend/services/`.
2. **Add env vars** to that brain's `.env` (pick keys based on which scrapers you wire up):
   ```bash
   # Mandatory for intent enrichment doctrine compliance:
   #   (none — kraken_crypto_quotes works keyless; intent_enrichment.py
   #    just consumes it. Equity vol/trend needs Alpaca though.)
   ALPACA_API_KEY=...
   ALPACA_API_SECRET=...

   # Optional — wire up as needed:
   ALPHA_VANTAGE_API_KEYS=k1,k2,k3       # rotates across keys to avoid 5/min ceiling
   BENZINGA_API_KEY=...                  # daily ceiling enforced
   POLYGON_API_KEY=...                   # free tier OK
   FRED_API_KEYS=...                     # free, get from st. louis fed
   ```
3. **Install deps** (most are already in `requirements.txt`):
   ```
   httpx
   requests
   yfinance
   beautifulsoup4
   ```
4. **Import + call**. Example for a brain that wants to add news shock to its council:
   ```python
   from services.benzinga_news_service import fetch_news
   from services.av_sentiment_feeder import update_sentiment_for_universe
   from services.news_shock_service import compute_news_shock_zscore

   counts = await fetch_news(["NVDA", "AAPL"])
   await update_sentiment_for_universe(["NVDA", "AAPL"])
   shock = await compute_news_shock_zscore("NVDA", db)
   ```

---

## Doctrine notes

- **Every scraper is `async def`** so the brain's event loop stays responsive.
- **Every scraper fails closed** — returns `[]` or `None` or sentinel values on error, never raises into the caller.
- **Every scraper has rate-limit + daily-ceiling guards** where the upstream demands it. Benzinga and AV especially — those will lock your account if you spam them.
- **No scraper makes a trading decision.** They produce data. The council's classifier decides what to do with it.
- **The canonical snapshot lives in `intent_enrichment.py`** — DO NOT invent your own field names. The 7 keys are doctrine.

---

## What's NOT in the box

- **Reddit / StockTwits scrapers** — Alpha doesn't ship one. If you want them, add a separate module; don't try to retrofit one of these.
- **X/Twitter API** — not implemented; Alpha skipped it because the API priced out.
- **Bloomberg / Reuters** — paid feeds, not part of the free/cheap stack.
- **Smart Money Verification / Dark Pool Lake** — those are *consumers* of `polygon_dark_pool_service` + `sec_13f_service`, not scrapers themselves. They live elsewhere in the brain.

---

## File list (for grep)

```
alpaca_equity_quotes.py
av_sentiment_feeder.py
benzinga_news_service.py
company_research_service.py
crypto_scraping_service.py
financial_scraping_service.py
fred_service.py
intent_enrichment.py
kraken_crypto_quotes.py
market_sentiment_service.py
news_shock_feeder.py
news_shock_service.py
polygon_dark_pool_service.py
real_estate_scraping_service.py
sec_13f_service.py
world_events_service.py
```

Total: 16 files, ~5,400 lines.

Generated from Alpha (preview pod) on 2026-02-19.
